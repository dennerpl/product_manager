package com.api.productionmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductionManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductionManagerApplication.class, args);
	}

}
